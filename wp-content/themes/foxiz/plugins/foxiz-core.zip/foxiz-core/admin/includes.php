<?php
/** Don't load directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

include_once FOXIZ_CORE_PATH . 'admin/taxonomy.php';
include_once FOXIZ_CORE_PATH . 'admin/sub-pages.php';
include_once FOXIZ_CORE_PATH . 'admin/core-helpers.php';
include_once FOXIZ_CORE_PATH . 'admin/import/ajax.php';
include_once FOXIZ_CORE_PATH . 'admin/core.php';
include_once FOXIZ_CORE_PATH . 'admin/rb-meta/rb-meta.php';
include_once FOXIZ_CORE_PATH . 'admin/fonts/init.php';
